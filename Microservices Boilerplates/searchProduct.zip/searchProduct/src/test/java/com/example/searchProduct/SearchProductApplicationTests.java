package com.example.searchProduct;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SearchProductApplicationTests {

	@Test
	void contextLoads() {
	}

}
