package com.example.addProduct;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AddProductApplicationTests {

	@Test
	void contextLoads() {
	}

}
